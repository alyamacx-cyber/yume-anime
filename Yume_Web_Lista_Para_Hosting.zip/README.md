# Yume — Anime Pinterest

Web app lista para desplegar con Node.js.

## Qué incluye

- Interfaz tipo galería/masonry inspirada en apps de descubrimiento visual.
- Búsqueda de anime.
- Búsqueda de personajes.
- Categorías.
- Carga progresiva.
- Galería de imágenes de personajes.
- Diseño responsive para Android y PC.
- Backend propio para que el navegador no tenga que llamar directamente a la API externa.
- Endpoint `/health` para comprobar que el servidor está vivo.

## Despliegue

Requisitos: Node.js 18 o superior.

```bash
npm install
npm start
```

La aplicación escuchará en el puerto indicado por `PORT` o, por defecto, en `3000`.

## Hosting

En un hosting compatible con Node.js:

- Build/install: `npm install`
- Start: `npm start`
- Port: usar la variable `PORT` proporcionada por el hosting.

No hace falta Termux para usar la página una vez desplegada.

## Fuente de contenido

Yume utiliza Jikan como intermediario para consultar información pública de MyAnimeList. Las imágenes y metadatos pertenecen a sus respectivos propietarios.

## Nota

La aplicación necesita Internet para consultar contenido nuevo. El backend evita el problema de CORS que aparece al abrir un HTML directamente como `file://`.
