import express from "express";

const app = express();
const PORT = process.env.PORT || 3000;
const JIKAN = "https://api.jikan.moe/v4";

app.use(express.static("public"));

async function jikan(path) {
  const response = await fetch(JIKAN + path, {
    headers: { "User-Agent": "Yume-Anime/1.0" }
  });
  const data = await response.json();
  if (!response.ok) {
    const err = new Error(data?.message || `Jikan HTTP ${response.status}`);
    err.status = response.status;
    throw err;
  }
  return data;
}

app.get("/api/anime", async (req, res) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const genre = req.query.genre ? `&genres=${encodeURIComponent(req.query.genre)}` : "";
    res.json(await jikan(`/anime?page=${page}&limit=18&sfw=true&order_by=popularity&sort=asc${genre}`));
  } catch (e) {
    res.status(e.status || 502).json({ error: e.message });
  }
});

app.get("/api/search", async (req, res) => {
  try {
    const q = String(req.query.q || "").trim();
    const type = req.query.type === "character" ? "character" : "anime";
    const page = Math.max(1, Number(req.query.page) || 1);
    if (!q) return res.json({ data: [], pagination: { has_next_page: false } });

    if (type === "character") {
      res.json(await jikan(`/characters?q=${encodeURIComponent(q)}&page=${page}&limit=18`));
    } else {
      res.json(await jikan(`/anime?q=${encodeURIComponent(q)}&page=${page}&limit=18&sfw=true`));
    }
  } catch (e) {
    res.status(e.status || 502).json({ error: e.message });
  }
});

app.get("/api/character/:id/pictures", async (req, res) => {
  try {
    res.json(await jikan(`/characters/${encodeURIComponent(req.params.id)}/pictures`));
  } catch (e) {
    res.status(e.status || 502).json({ error: e.message });
  }
});

app.get("/health", (req,res) => res.json({ ok:true, service:"Yume" }));

app.get("*", (req,res) => res.sendFile("index.html", { root: "public" }));

app.listen(PORT, () => console.log(`Yume running on port ${PORT}`));
